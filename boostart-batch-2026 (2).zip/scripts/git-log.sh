#!/bin/bash
echo "=== Historial de commits ==="
git log --oneline --all
